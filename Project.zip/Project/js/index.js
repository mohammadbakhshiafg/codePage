
$(document).ready(function(){
    // Section title && Div Slides I Use This Part For A Create A Slide With ToggleClasses
    // Start Section Title
    $("#prev").click(function(){
        $(".slide-1").removeClass('active');
        $(".slide-2").addClass('active')
    })

    $("#next").click(function(){
        $(".slide-2").removeClass('active');
        $(".slide-1").addClass('active')
    })
     // End Section Title

    //  Toggle menu ul / Section nav Script
    $('.menu-btn').on('click',function(){
        $('.nav .wrapper.flex ul').toggleClass('active')
        $('.menu-btn i').toggleClass('active')
    })
})